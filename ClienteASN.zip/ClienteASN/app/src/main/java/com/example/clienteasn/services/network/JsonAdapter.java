package com.example.clienteasn.services.network;

import com.example.clienteasn.services.pojo.LoginPOJO;
import com.example.clienteasn.services.pojo.RegisterPOJO;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonAdapter {
    public static LoginPOJO loginAdapter(JSONObject jsonObject) throws JSONException {
        LoginPOJO res = new LoginPOJO();
        res.setToken(jsonObject.getString("token"));
        return res;
    }

    public static RegisterPOJO registerAdapter(JSONObject jsonObject) throws  JSONException {
        RegisterPOJO res = new RegisterPOJO();
        res.setUsuario(jsonObject.getString("usuario"));
        return res;
    }

}
