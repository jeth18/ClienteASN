package com.example.clienteasn.services.pojo;

public class RegisterPOJO {
    private String usuario;


    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

}
